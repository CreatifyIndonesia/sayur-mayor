<?php
session_start();
include('config.php');
// var_dump($_POST);
if($_POST){
	if($_POST["type"] == "loginAdmin"){
		if(isset($_POST["email"]) && isset($_POST["password"])){
			$email = $_POST['email'];
			$password = $_POST['password'];
			$sql = "SELECT * FROM `petani` WHERE LOWER(EMAIL_PETANI) = '$email' and DECODE(LOWER(PASSWORD_PETANI), 'petanimayor1029') = '$password'";
			// var_dump($sql);
			$result = $mysqli->query($sql);
			if($result->num_rows > 0){
				$row = $result->fetch_assoc();
				$_SESSION["id_admin"] = $row['id_petani'];
				$_SESSION["email"] = $row['email'];
				$_SESSION["status_petani"] = $row['status_petani'];
				header('Location: ../review.php');
			} else {
    			    echo '<script>alert("Username atau Password Salah")</script>';
    			    echo '<script>window.location = "../sign-in.php"</script>';
    			}
    		}  else {
    	header('Location: ../index.php');
		}
	}
}
?>